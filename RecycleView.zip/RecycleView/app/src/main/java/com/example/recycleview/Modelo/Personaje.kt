package com.example.recycleview.Modelo

data class Personaje(val nombre:String,val foto:String)